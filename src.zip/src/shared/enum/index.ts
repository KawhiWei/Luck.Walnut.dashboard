/**
 * 排序枚举
 */
export enum ESort {
  Ascending,
  Descending
}

export enum EOperate {
  view,
  add,
  update
}
