import { IDataRequest } from "data-request";

export default interface IBaseservices {
  dataRequest: IDataRequest;
}
