export const USER_MENU = 'USER_MENU';
