import * as echarts from 'echarts';

import { useEffect, useState } from "react";

/**
 * 折线图组件
 * @returns 
 */
const StackedLineCharts = () => {

  /**
   * 页面初始化事件
   */
  useEffect(() => {

  });
  return (
    <>
    </>
  )
}
export default StackedLineCharts;