/**
 * 公告组件
 */
const Notice=() => {

    
    return (
        <>
        </>
    )
}
export default Notice;